<?php
/**
 * Homepage - Teddy Bear Paradise 🐻
 * FINAL PERFECT VERSION - No loading issues, all images working
 */

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Simple configuration
if (file_exists('config/config.php')) {
    try {
        require_once 'config/config.php';
    } catch (Exception $e) {
        define('IMG_PATH', 'images/');
        define('SITE_URL', '/teddy_bear_shop/');
    }
} else {
    define('IMG_PATH', 'images/');
    define('SITE_URL', '/teddy_bear_shop/');
}

$page_title = 'Trang chủ - Teddy Bear Paradise 🐻';
$page_description = 'Cửa hàng gấu bông đáng yêu nhất Việt Nam';

// Categories with real image files
$categories = [
    [
        'id' => 1, 
        'name' => 'Gấu Teddy Classic', 
        'slug' => 'gau-teddy-classic', 
        'description' => 'Gấu Teddy truyền thống đáng yêu', 
        'image' => 'category-teddy.jpg'
    ],
    [
        'id' => 2, 
        'name' => 'Gấu Panda', 
        'slug' => 'gau-panda', 
        'description' => 'Gấu Panda siêu cute', 
        'image' => 'category-panda.jpg'
    ],
    [
        'id' => 3, 
        'name' => 'Gấu Đặc Biệt', 
        'slug' => 'gau-dac-biet', 
        'description' => 'Gấu phiên bản giới hạn', 
        'image' => 'category-special.jpg'
    ],
    [
        'id' => 4, 
        'name' => 'Gấu Động Vật', 
        'slug' => 'gau-dong-vat', 
        'description' => 'Gấu hình động vật khác', 
        'image' => 'category-animals.jpg'
    ]
];

// Featured products with existing image files
$featured_products = [
    [
        'id' => 1, 
        'name' => 'Gấu Teddy Nâu Classic', 
        'slug' => 'gau-teddy-nau-classic',
        'short_description' => 'Gấu Teddy nâu cổ điển, mềm mại và an toàn',
        'price' => 150000, 
        'sale_price' => 120000, 
        'main_image' => 'teddy-01.jpg',
        'rating' => 5, 
        'review_count' => 24, 
        'is_limited' => false
    ],
    [
        'id' => 2, 
        'name' => 'Gấu Teddy Hồng Dễ Thương', 
        'slug' => 'gau-teddy-hong-de-thuong',
        'short_description' => 'Gấu Teddy màu hồng xinh xắn cho bé gái',
        'price' => 180000, 
        'sale_price' => null, 
        'main_image' => 'teddy-02.jpg',
        'rating' => 5, 
        'review_count' => 18, 
        'is_limited' => false
    ],
    [
        'id' => 3, 
        'name' => 'Gấu Panda Đen Trắng', 
        'slug' => 'gau-panda-den-trang',
        'short_description' => 'Gấu Panda đen trắng với biểu cảm dễ thương',
        'price' => 220000, 
        'sale_price' => 200000, 
        'main_image' => 'panda-01.jpg',
        'rating' => 4, 
        'review_count' => 32, 
        'is_limited' => false
    ],
    [
        'id' => 5, 
        'name' => 'Gấu Koala Xám Úc', 
        'slug' => 'gau-koala-xam-uc',
        'short_description' => 'Gấu Koala đáng yêu từ Úc',
        'price' => 200000, 
        'sale_price' => 180000, 
        'main_image' => 'koala-01.jpg',
        'rating' => 5, 
        'review_count' => 15, 
        'is_limited' => true
    ]
];

// Price format function
if (!function_exists('formatPrice')) {
    function formatPrice($price) {
        return number_format($price, 0, ',', '.') . ' ₫';
    }
}

include 'includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center" style="min-height: 65vh;">
            <div class="col-lg-6">
                <div class="hero-content">
                    <h1 class="hero-title mb-4">
                        Thiên đường
                        <span class="highlight">Gấu Bông</span>
                    </h1>
                    
                    <p class="hero-subtitle mb-4">
                        Khám phá bộ sưu tập gấu bông cao cấp, mềm mại và an toàn nhất. 
                        Món quà hoàn hảo để trao gửi yêu thương đến người thân yêu!
                    </p>
                    
                    <div class="hero-features mb-4">
                        <div class="feature-item">
                            Chất lượng cao
                        </div>
                        <div class="feature-item">
                            An toàn 100%
                        </div>
                        <div class="feature-item">
                            Giao hàng nhanh
                        </div>
                    </div>
                    
                    <div class="hero-buttons">
                        <a href="pages/products.php" class="cute-btn">
                            Mua sắm ngay
                        </a>
                        <a href="pages/about.php" class="cute-btn-outline">
                            Tìm hiểu thêm
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="text-center">
                    <img src="<?php echo IMG_PATH; ?>bunny-bear.jpg" 
                         alt="Teddy Bear Collection" 
                         class="img-fluid rounded shadow-lg"
                         style="max-width: 100%; height: auto;"
                         onerror="this.style.background='linear-gradient(45deg, #ff6b96, #f093fb)'; this.style.color='white'; this.style.display='flex'; this.style.alignItems='center'; this.style.justifyContent='center'; this.innerHTML='🐻 Teddy Bear Paradise'; this.style.fontSize='2rem'; this.style.fontWeight='bold'; this.style.minHeight='400px'; this.style.borderRadius='15px';">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Categories Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title fw-bold text-dark">
                Danh mục sản phẩm
            </h2>
            <p class="section-subtitle text-muted">Tìm kiếm những chú gấu bông phù hợp với sở thích của bạn</p>
        </div>
        
        <div class="row g-4">
            <?php foreach ($categories as $category): ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="card category-card border-0 shadow-sm rounded-4 overflow-hidden position-relative h-100">
                    <div class="category-image" style="height: 220px; background: #fff5f7;">
                        <img src="<?php echo IMG_PATH . $category['image']; ?>" 
                             alt="<?php echo htmlspecialchars($category['name']); ?>"
                             class="w-100 h-100 object-fit-cover"
                             onerror="this.src='<?php echo IMG_PATH; ?>placeholder.jpg';">
                        <a href="pages/products.php?category=<?php echo urlencode($category['slug']); ?>"
                           class="btn btn-white btn-sm rounded-pill px-3 py-1 fw-semibold shadow-sm category-view-btn"
                           style="position:absolute;bottom:16px;left:50%;transform:translateX(-50%);z-index:2;white-space:nowrap;background:rgba(255,255,255,0.95);">
                            Xem ngay <i class="fas fa-arrow-right ms-1 small"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="py-5" style="background-color: var(--bg-subtle);">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title fw-bold text-dark">
                Sản phẩm nổi bật
            </h2>
            <p class="section-subtitle text-muted">Những mẫu gấu bông được yêu thích và bán chạy nhất</p>
        </div>
        
        <div class="row g-4">
            <?php foreach ($featured_products as $product): ?>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card product-card h-100 border-0 shadow-sm rounded-4 overflow-hidden position-relative">
                    <div class="product-image position-relative" style="height: 240px; background: #fff5f7;">
                        <img src="<?php echo IMG_PATH . $product['main_image']; ?>" 
                             alt="<?php echo htmlspecialchars($product['name']); ?>"
                             class="w-100 h-100 object-fit-cover"
                             onerror="this.src='<?php echo IMG_PATH; ?>placeholder.jpg';">
                        
                        <?php if (!empty($product['sale_price'])): ?>
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-danger rounded-pill px-2 py-1">SALE</span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($product['is_limited'])): ?>
                        <div class="position-absolute top-0 start-0 m-2">
                            <span class="badge bg-warning text-dark rounded-pill px-2 py-1">HOT</span>
                        </div>
                        <?php endif; ?>
                        
                        <div class="product-overlay">
                            <div class="product-actions d-flex gap-2">
                                <button class="btn btn-primary btn-sm rounded-circle add-to-cart-btn" 
                                        data-product-id="<?php echo $product['id']; ?>"
                                        type="button" title="Thêm vào giỏ">
                                    <i class="fas fa-cart-plus"></i>
                                </button>
                                <a href="pages/product-detail.php?slug=<?php echo urlencode($product['slug']); ?>" 
                                   class="btn btn-light btn-sm rounded-circle" 
                                   title="Xem chi tiết">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <button class="btn btn-danger btn-sm rounded-circle" 
                                        onclick="addToWishlist(<?php echo $product['id']; ?>)"
                                        title="Thêm vào yêu thích">
                                    <i class="fas fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body p-3 d-flex flex-column">
                        <div class="product-rating mb-2 small text-warning">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas <?php echo $i <= ($product['rating'] ?? 0) ? 'fa-star' : 'fa-star text-muted opacity-25'; ?>"></i>
                            <?php endfor; ?>
                            <span class="text-muted ms-1 small">(<?php echo $product['review_count'] ?? 0; ?>)</span>
                        </div>
                        
                        <h6 class="product-name fw-bold text-dark mb-1 text-truncate" title="<?php echo htmlspecialchars($product['name']); ?>">
                            <a href="pages/product-detail.php?slug=<?php echo urlencode($product['slug']); ?>" class="text-decoration-none text-dark hover-pink">
                                <?php echo htmlspecialchars($product['name']); ?>
                            </a>
                        </h6>
                        
                        <p class="card-text text-muted small flex-grow-1 text-truncate"><?php echo htmlspecialchars($product['short_description']); ?></p>
                        
                        <div class="product-price mb-3">
                            <?php if (!empty($product['sale_price'])): ?>
                                <span class="fw-bold text-danger fs-5"><?php echo formatPrice($product['sale_price']); ?></span>
                                <small class="text-decoration-line-through text-muted ms-1"><?php echo formatPrice($product['price']); ?></small>
                            <?php else: ?>
                                <span class="fw-bold text-primary fs-5"><?php echo formatPrice($product['price']); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button class="btn btn-primary btn-sm rounded-pill add-to-cart-btn py-2" 
                                    data-product-id="<?php echo $product['id']; ?>"
                                    type="button">
                                <i class="fas fa-shopping-cart me-1"></i> Thêm vào giỏ
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-5">
            <a href="pages/products.php" class="btn btn-outline-primary rounded-pill px-4 py-2">
                Xem tất cả sản phẩm <i class="fas fa-arrow-right ms-1"></i>
            </a>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title fw-bold text-dark">
                Cam kết từ Teddy Bear Paradise
            </h2>
            <p class="section-subtitle text-muted">Chất lượng sản phẩm và dịch vụ là ưu tiên hàng đầu của chúng tôi</p>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-3 col-md-6">
                <div class="card p-4 text-center h-100 border-0 shadow-sm rounded-4">
                    <div class="rounded-circle bg-pink-light d-inline-flex align-items-center justify-content-center mx-auto mb-3" style="width: 65px; height: 65px;">
                        <i class="fas fa-award text-pink fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Chất lượng cao</h5>
                    <p class="text-muted small mb-0">
                        Sản phẩm được chọn lọc kỹ càng, đảm bảo chất lượng và độ bền tốt nhất
                    </p>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="card p-4 text-center h-100 border-0 shadow-sm rounded-4">
                    <div class="rounded-circle bg-pink-light d-inline-flex align-items-center justify-content-center mx-auto mb-3" style="width: 65px; height: 65px;">
                        <i class="fas fa-shield-alt text-pink fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">An toàn 100%</h5>
                    <p class="text-muted small mb-0">
                        Chất liệu bông xoắn 3 chiều an toàn, không kích ứng da cho trẻ nhỏ
                    </p>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="card p-4 text-center h-100 border-0 shadow-sm rounded-4">
                    <div class="rounded-circle bg-pink-light d-inline-flex align-items-center justify-content-center mx-auto mb-3" style="width: 65px; height: 65px;">
                        <i class="fas fa-shipping-fast text-pink fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Giao hàng nhanh</h5>
                    <p class="text-muted small mb-0">
                        Đóng gói cẩn thận, giao hàng toàn quốc nhanh chóng trong 24-48h
                    </p>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="card p-4 text-center h-100 border-0 shadow-sm rounded-4">
                    <div class="rounded-circle bg-pink-light d-inline-flex align-items-center justify-content-center mx-auto mb-3" style="width: 65px; height: 65px;">
                        <i class="fas fa-headset text-pink fs-3"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Hỗ trợ tận tình</h5>
                    <p class="text-muted small mb-0">
                        Đội ngũ tư vấn nhiệt tình, sẵn sàng giải đáp và hỗ trợ mọi lúc
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Simple Footer -->
<?php include 'includes/footer.php'; ?>

<!-- FINAL OPTIMIZED JAVASCRIPT -->
<script>
// ===== FORCE PREVENT LOADING ISSUES =====
(function() {
    'use strict';
    
    function forceCleanup() {
        const selectors = ['.loading', '.spinner', '.preloader', '#loadingOverlay', '.loading-overlay', '[class*="loading"]', '[id*="loading"]'];
        selectors.forEach(selector => {
            try {
                document.querySelectorAll(selector).forEach(el => {
                    el.style.display = 'none';
                    el.style.opacity = '0';
                    el.style.visibility = 'hidden';
                    if (el.parentNode) el.parentNode.removeChild(el);
                });
            } catch (e) {}
        });
        
        document.body.classList.remove('loading');
        document.body.style.overflow = 'visible';
        document.body.style.pointerEvents = 'auto';
        document.documentElement.classList.remove('loading');
    }
    
    forceCleanup();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', forceCleanup, { once: true });
    }
    setTimeout(forceCleanup, 1000);
})();

console.log('🐻 Teddy Bear Shop loading...');

// ===== SIMPLE NOTIFICATION SYSTEM =====
function showNotification(message, type = 'info') {
    let container = document.getElementById('notifications');
    if (!container) {
        container = document.createElement('div');
        container.id = 'notifications';
        container.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
        document.body.appendChild(container);
    }
    
    // Remove existing notifications
    container.innerHTML = '';
    
    const colors = { success: '#28a745', error: '#dc3545', info: '#17a2b8', warning: '#ffc107' };
    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    
    const notification = document.createElement('div');
    notification.style.cssText = `
        background: ${colors[type]}; color: white; padding: 15px 20px; border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15); margin-bottom: 10px;
        transform: translateX(100%); opacity: 0; transition: all 0.3s ease;
        display: flex; align-items: center; gap: 10px; font-weight: 500;
    `;
    
    notification.innerHTML = `
        <span>${icons[type]}</span>
        <span style="flex: 1;">${message}</span>
        <button onclick="this.parentElement.remove()" 
                style="background: none; border: none; color: white; font-size: 18px; cursor: pointer;">×</button>
    `;
    
    container.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
        notification.style.opacity = '1';
    }, 10);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.transform = 'translateX(100%)';
            notification.style.opacity = '0';
            setTimeout(() => notification.remove(), 300);
        }
    }, 3000);
}

// ===== CART FUNCTIONS =====
let cartCount = 0;

function addToCart(productId, quantity = 1) {
    console.log('Adding product to cart:', productId);
    
    // Update cart count
    cartCount++;
    const cartCountElement = document.getElementById('cartCount');
    if (cartCountElement) {
        cartCountElement.textContent = cartCount;
        cartCountElement.style.animation = 'bounce 0.6s ease';
        setTimeout(() => cartCountElement.style.animation = '', 600);
    }
    
    showNotification('🛒 Đã thêm sản phẩm vào giỏ hàng!', 'success');
    showQuickCartActions();
}

function addToWishlist(productId) {
    showNotification('💝 Đã thêm vào danh sách yêu thích!', 'success');
    
    // Find the button that was clicked
    const buttons = document.querySelectorAll(`button[onclick*="addToWishlist(${productId})"]`);
    buttons.forEach(button => {
        const heart = button.querySelector('i');
        if (heart) {
            heart.style.color = '#ff6b96';
            heart.style.transform = 'scale(1.2)';
            setTimeout(() => heart.style.transform = 'scale(1)', 300);
        }
    });
}

function quickView(productSlug) {
    window.location.href = `pages/product-detail.php?slug=${encodeURIComponent(productSlug)}`;
}

function subscribeNewsletter(event) {
    event.preventDefault();
    const form = event.target;
    const email = form.querySelector('input[type="email"]').value;
    
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showNotification('📧 Vui lòng nhập email hợp lệ!', 'warning');
        return;
    }
    
    showNotification('⏳ Đang đăng ký...', 'info');
    
    setTimeout(() => {
        showNotification('💌 Cảm ơn bạn đã đăng ký nhận tin!', 'success');
        form.reset();
    }, 1000);
}

function showQuickCartActions() {
    const existing = document.querySelector('.quick-cart-actions');
    if (existing) existing.remove();
    
    const quickActions = document.createElement('div');
    quickActions.className = 'quick-cart-actions';
    quickActions.style.cssText = `
        position: fixed; bottom: 20px; right: 20px; z-index: 1000;
        background: white; border-radius: 15px; box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        padding: 20px; min-width: 300px; transform: translateY(100%); opacity: 0;
        transition: all 0.3s ease;
    `;
    
    quickActions.innerHTML = `
        <div style="text-align: center;">
            <h6 style="margin-bottom: 15px; color: #2c3e50;">🛒 Sản phẩm đã được thêm!</h6>
            <div style="display: flex; gap: 10px; justify-content: center;">
                <a href="cart/" class="btn btn-primary btn-sm">
                    <span style="font-size: 1.1rem; margin-right: 5px;">🛒</span> Xem giỏ hàng
                </a>
                <button class="btn btn-success btn-sm" onclick="this.closest('.quick-cart-actions').remove()">
                    <span style="font-size: 1rem; margin-right: 5px;">🛍️</span> Tiếp tục mua
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(quickActions);
    
    setTimeout(() => {
        quickActions.style.transform = 'translateY(0)';
        quickActions.style.opacity = '1';
    }, 10);
    
    setTimeout(() => {
        if (quickActions.parentNode) {
            quickActions.style.transform = 'translateY(100%)';
            quickActions.style.opacity = '0';
            setTimeout(() => quickActions.remove(), 300);
        }
    }, 5000);
}

// ===== SCROLL TO TOP BUTTON =====
function createScrollToTopButton() {
    if (document.getElementById('scrollToTop')) return;
    
    const scrollBtn = document.createElement('button');
    scrollBtn.id = 'scrollToTop';
    scrollBtn.innerHTML = '<span style="font-size: 1.2rem;">⬆️</span>';
    scrollBtn.style.cssText = `
        position: fixed; bottom: 30px; left: 30px; width: 50px; height: 50px;
        background: linear-gradient(45deg, #ff6b96, #f093fb); color: white;
        border: none; border-radius: 50%; cursor: pointer; opacity: 0;
        visibility: hidden; transform: translateY(20px); transition: all 0.3s ease;
        z-index: 1000; box-shadow: 0 4px 15px rgba(255, 107, 150, 0.3);
        display: flex; align-items: center; justify-content: center; font-size: 1.2rem;
    `;

    scrollBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    document.body.appendChild(scrollBtn);
}

// ===== SCROLL HANDLER =====
function handleScroll() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollBtn = document.getElementById('scrollToTop');
    
    if (scrollBtn) {
        if (scrollTop > 300) {
            scrollBtn.style.opacity = '1';
            scrollBtn.style.visibility = 'visible';
            scrollBtn.style.transform = 'translateY(0)';
        } else {
            scrollBtn.style.opacity = '0';
            scrollBtn.style.visibility = 'hidden';
            scrollBtn.style.transform = 'translateY(20px)';
        }
    }
}

// ===== INITIALIZE EVERYTHING =====
function initializeTeddyShop() {
    try {
        console.log('🐻 Initializing Teddy Bear Shop...');
        
        createScrollToTopButton();
        window.addEventListener('scroll', handleScroll, { passive: true });
        
        console.log('✅ Teddy Bear Shop initialized successfully!');
        
    } catch (error) {
        console.error('❌ Initialization error:', error);
    }
}

// ===== AUTO INITIALIZATION =====
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeTeddyShop, { once: true });
} else {
    initializeTeddyShop();
}

// Add CSS animations
const animationStyles = document.createElement('style');
animationStyles.textContent = `
@keyframes bounce {
    0%, 100% { transform: scale(1); }
    25% { transform: scale(1.1); }
    50% { transform: scale(1.2); }
    75% { transform: scale(1.1); }
}

.btn {
    transition: all 0.3s ease;
}

.btn:hover {
    transform: translateY(-2px);
}
`;

if (!document.getElementById('teddy-animations')) {
    animationStyles.id = 'teddy-animations';
    document.head.appendChild(animationStyles);
}

console.log('🐻 Teddy Bear Shop JavaScript loaded and ready! 🚀');
</script>
<script src="js/cart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('🏠 Homepage: Initializing cart...');
    if (typeof TeddyBearCart !== 'undefined') {
        window.teddyCart = new TeddyBearCart();
        console.log('✅ Homepage: Cart initialized');
        window.teddyCart.loadCartCount();
        const buttons = document.querySelectorAll('.add-to-cart-btn');
        console.log('🔍 Homepage: Found buttons:', buttons.length);
        buttons.forEach((btn, i) => {
            console.log(`Homepage Button ${i}:`, {
                productId: btn.dataset.productId,
                classes: btn.className
            });
        });
    } else {
        console.error('❌ Homepage: TeddyBearCart not found');
    }
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Toggle overlay khi click vào card
  document.querySelectorAll('.category-card').forEach(function(card) {
    card.addEventListener('click', function(e) {
      // Ẩn overlay của các card khác
      document.querySelectorAll('.category-card.show-overlay').forEach(function(other) {
        if (other !== card) other.classList.remove('show-overlay');
      });
      // Toggle overlay cho card này
      card.classList.toggle('show-overlay');
      e.stopPropagation();
    });
  });
  // Click ra ngoài thì ẩn overlay
  document.addEventListener('click', function() {
    document.querySelectorAll('.category-card.show-overlay').forEach(function(card) {
      card.classList.remove('show-overlay');
    });
  });
});
</script>
</body>
</html>