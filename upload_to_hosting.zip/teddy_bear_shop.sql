-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: teddy_bear_shop
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('super_admin','admin') DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin','admin@teddyshop.com','$2y$10$OT8NrGD4myy3LQBJI82EoOUTRxTb0wJpSzaVtPVO7MOricGERqDiC','Super Admin','super_admin','2025-06-07 16:50:38','active'),(2,'demo_admin','demo@teddyshop.com','$2y$10$dPwinYt.Rw.7snLWfkSsXep1Y0ITQnjWENZ6ns4b7BPaerdHsL5Du','Admin User','admin','2025-06-12 15:40:53','active');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `size` varchar(50) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_product` (`user_id`,`product_id`),
  KEY `product_id` (`product_id`),
  KEY `idx_cart_user` (`user_id`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (36,7,1,3,'','2025-07-05 07:06:10','2025-07-05 07:22:24'),(37,7,13,5,'','2025-07-05 07:23:39','2025-07-05 07:36:06'),(44,2,1,4,'','2025-07-07 03:52:41','2025-07-07 03:58:16'),(45,2,13,2,'','2025-07-07 04:48:21','2025-07-07 05:26:25'),(60,8,14,1,'','2025-12-28 15:49:56','2025-12-28 15:49:56'),(61,8,13,2,'','2025-12-28 16:43:35','2025-12-28 16:43:35');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Gấu Teddy Classic','gau-teddy-classic','Những chú gấu Teddy truyền thống đáng yêu','category-teddy.jpg','active','2025-06-07 16:50:38'),(2,'Gấu Panda','gau-panda','Gấu Panda siêu cute và dễ thương','category-panda.jpg','active','2025-06-07 16:50:38'),(3,'Gấu Khổng Lồ','gau-khong-lo','Những chú gấu size khổng lồ để ôm','category-giant.jpg','active','2025-06-07 16:50:38'),(4,'Gấu Đặc Biệt','gau-dac-biet','Gấu phiên bản giới hạn và độc đáo','category-special.jpg','active','2025-06-07 16:50:38'),(5,'Gấu Động Vật','gau-dong-vat','Gấu hình các loài động vật khác','category-animals.jpg','active','2025-06-07 16:50:38');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `status` enum('new','read','replied') DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_messages`
--

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
INSERT INTO `contact_messages` VALUES (1,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','Gấu','aaaa','new','2025-06-12 15:49:56');
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('percentage','fixed') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `minimum_amount` decimal(10,2) DEFAULT 0.00,
  `usage_limit` int(11) DEFAULT NULL,
  `usage_count` int(11) DEFAULT 0,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (1,'HELLO2025','Giảm giá sốc','percentage',10.00,0.00,1,1,'2000-01-01','2099-12-31','active','2025-07-04 19:28:31'),(2,'BEAR50K','Gấu bông giảm 50K','fixed',50000.00,300000.00,NULL,0,'2025-07-07','2025-08-06','active','2025-07-07 10:05:00'),(3,'SINHNHATSHOP','giảm dịp sinh nhật','percentage',50.00,0.00,NULL,6,'2025-12-26','2026-01-25','active','2025-12-26 19:09:42'),(4,'TET20226','May mắn','percentage',20.00,200000.00,10,1,'2025-12-26','2026-01-25','active','2025-12-26 19:10:59'),(5,'TET2026','giảm sốc','percentage',20.00,200000.00,50,4,'2026-02-04','2026-03-06','active','2026-02-04 03:15:41');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_orders`
--

DROP TABLE IF EXISTS `custom_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `search_keyword` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `selected_image_url` varchar(500) DEFAULT NULL COMMENT 'Ảnh mà khách chọn sau khi tìm kiếm',
  `rating` int(11) DEFAULT 0 COMMENT '0=chưa đánh giá, 1-5=đánh giá sao từ khách',
  `status` enum('waiting_images','image_selected','confirmed','viewed','responded','ordered','rejected') DEFAULT 'waiting_images' COMMENT 'waiting_images=chờ ảnh, image_selected=khách chọn ảnh, confirmed=khách xác nhận, viewed=shop xem, ...',
  `shop_message` longtext DEFAULT NULL COMMENT 'Phản hồi từ shop',
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_email` (`customer_email`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_orders`
--

LOCK TABLES `custom_orders` WRITE;
/*!40000 ALTER TABLE `custom_orders` DISABLE KEYS */;
INSERT INTO `custom_orders` VALUES (2,'Nguyễn Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','gấu hướng dương','gấu hoa','','https://plus.unsplash.com/premium_photo-1725075087153-610264ca9cbd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8MjF8fGNyYWZ0JTIwdGVkZHklMjBiZWFyfGVufDB8fHx8MTc2Njk0MzI2NXww&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2025-12-28 17:34:20','2025-12-28 17:34:34'),(3,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','gấu khỉ','tạo gấu con khỉ xinh','','https://plus.unsplash.com/premium_photo-1683705132888-8dd65f57f276?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8NDF8fHN0dWZmZWQlMjBhbmltYWwlMjB0b3l8ZW58MHx8fHwxNzY4MTM4ODYyfDA&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2026-01-11 13:40:57','2026-01-11 13:41:20'),(4,'Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','Gấu Teddy','gấu cute','','https://plus.unsplash.com/premium_photo-1661322749566-7ca22b3745fa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8MjF8fHN0dWZmZWQlMjBhbmltYWwlMjB0b3l8ZW58MHx8fHwxNzY4MzcwMjQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2026-01-14 05:57:21','2026-01-14 05:59:14'),(5,'Nguyễn Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','Gấu nhỏ','gấu nhỏ cute','','https://plus.unsplash.com/premium_photo-1725075087077-4a904603f416?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8MjF8fHNvZnQlMjB0ZWRkeSUyMGRvbGx8ZW58MHx8fHwxNzY4MzcwNDExfDA&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2026-01-14 06:00:03','2026-01-14 06:01:38'),(6,'Nguyễn Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','gấu lớn','gấu nhỏ cute','','https://plus.unsplash.com/premium_photo-1702214406609-00e1730bc65a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8NDF8fHRlZGR5JTIwYmVhciUyMGN1dGV8ZW58MHx8fHwxNzY4MzcwNDA5fDA&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2026-01-14 06:03:44','2026-01-14 06:05:21'),(7,'Nguyễn Ngọc Duy','ngocduy12345123@gmail.com','0358591058','gấu nhỏ','gấu nhỏ cute','','https://plus.unsplash.com/premium_photo-1755534520270-31a56c43ea9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8NDF8fHN0dWZmZWQlMjBhbmltYWwlMjB0b3l8ZW58MHx8fHwxNzY4MzcwNjMzfDA&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2026-01-14 06:09:43','2026-01-14 06:10:01'),(8,'Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','gấu cute','gấu cute màu trắng','','https://plus.unsplash.com/premium_photo-1725075087153-610264ca9cbd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8MjF8fHNvZnQlMjB0ZWRkeSUyMGRvbGx8ZW58MHx8fHwxNzcwMTgwNjMzfDA&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2026-02-04 04:50:26','2026-02-04 04:50:49'),(9,'Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','gấu cute','gấu cute màu trắng','','https://plus.unsplash.com/premium_photo-1725075087153-610264ca9cbd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMjA3fDB8MXxzZWFyY2h8MjF8fHNvZnQlMjB0ZWRkeSUyMGRvbGx8ZW58MHx8fHwxNzcwMTgwNjMzfDA&ixlib=rb-4.1.0&q=80&w=1080',5,'confirmed',NULL,'::1','2026-02-04 06:24:38','2026-02-04 06:24:53');
/*!40000 ALTER TABLE `custom_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,1,1,'Gấu Teddy Nâu Classic','teddy-01.jpg',1,120000.00,120000.00),(2,1,6,'Gấu Teddy Xanh Dương','teddy-blue.jpg',1,170000.00,170000.00),(3,1,2,'Gấu Teddy Hồng Dễ Thương','teddy-02.jpg',4,180000.00,720000.00),(4,2,1,'Gấu Teddy Nâu Classic','teddy-01.jpg',3,120000.00,360000.00),(5,3,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',1,140000.00,140000.00),(6,4,3,'Gấu Panda Đen Trắng','panda-01.jpg',1,200000.00,200000.00),(7,4,2,'Gấu Teddy Hồng Dễ Thương','teddy-02.jpg',1,160000.00,160000.00),(8,4,1,'Gấu Teddy Nâu Classic','teddy-01.jpg',1,120000.00,120000.00),(9,5,22,'Gấu Panda Giant Hug','panda-giant.jpg',1,250000.00,250000.00),(10,5,1,'Gấu Teddy Nâu Classic','teddy-01.jpg',2,120000.00,240000.00),(11,6,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',8,140000.00,1120000.00),(12,6,2,'Gấu Teddy Hồng Dễ Thương','teddy-02.jpg',1,160000.00,160000.00),(13,7,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',2,140000.00,280000.00),(14,7,3,'Gấu Panda Đen Trắng','panda-01.jpg',1,200000.00,200000.00),(15,8,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',1,140000.00,140000.00),(16,8,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',1,165000.00,165000.00),(17,9,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',2,165000.00,330000.00),(18,9,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',2,140000.00,280000.00),(19,10,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',2,165000.00,330000.00),(20,11,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',2,165000.00,330000.00),(21,12,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',2,165000.00,330000.00),(22,13,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',2,165000.00,330000.00),(23,14,15,'Gấu Teddy Mini Pocket','teddy-mini.jpg',7,70000.00,490000.00),(24,15,4,'Gấu Bắc Cực Trắng','polar-01.jpg',3,250000.00,750000.00),(25,16,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',3,140000.00,420000.00),(26,17,15,'Gấu Teddy Mini Pocket','teddy-mini.jpg',1,70000.00,70000.00),(27,18,15,'Gấu Teddy Mini Pocket','teddy-mini.jpg',1,70000.00,70000.00),(28,19,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',2,165000.00,330000.00),(29,20,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',3,165000.00,495000.00),(30,21,22,'Gấu Panda Giant Hug','panda-giant.jpg',1,250000.00,250000.00),(31,22,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',4,140000.00,560000.00),(32,23,15,'Gấu Teddy Mini Pocket','teddy-mini.jpg',3,70000.00,210000.00),(33,24,14,'Gấu Teddy Xám Khói','teddy-gray.jpg',1,165000.00,165000.00),(34,25,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',1,140000.00,140000.00),(35,26,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',2,140000.00,280000.00),(36,27,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',2,140000.00,280000.00),(37,28,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',2,140000.00,280000.00),(38,29,13,'Gấu Teddy Trắng Ngọc Trai','teddy-white.jpg',2,140000.00,280000.00);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `shipping_address` text NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `shipping_fee` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cod','bank_transfer','momo','zalopay') DEFAULT 'cod',
  `payment_status` enum('pending','paid','failed') DEFAULT 'pending',
  `order_status` enum('pending','confirmed','processing','shipping','delivered','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `idx_orders_user` (`user_id`),
  KEY `idx_orders_status` (`order_status`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'TB202506290780',2,'Ngọc Duy','ngocduy12345124@gmail.com','0358591058','Bình Định',1010000.00,0.00,1010000.00,'cod','pending','pending','','2025-06-29 15:38:40','2025-06-29 15:38:40'),(2,'TB202506306718',NULL,'Nguyễn Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','Bình Định',360000.00,30000.00,390000.00,'cod','pending','delivered','','2025-06-30 08:27:24','2025-07-04 20:39:20'),(3,'TB202507042992',NULL,'Ngọc Duy','Ngocduy12345123@gamil.com','0358591058','Bình Định',140000.00,30000.00,170000.00,'bank_transfer','pending','delivered','','2025-07-04 09:08:34','2025-07-04 19:20:02'),(4,'TB202507056861',3,'Ngọc Duy','duynn1809@ut.edu.vn','0358591058','Bình Định',480000.00,30000.00,510000.00,'cod','pending','pending','','2025-07-05 08:00:02','2025-07-05 08:00:02'),(5,'TB202507050518',2,'Ngọc Duy','ngocduy12345124@gmail.com','0358591058','Bình ĐỊnh',490000.00,30000.00,520000.00,'cod','pending','pending','','2025-07-05 10:09:20','2025-07-05 10:09:20'),(6,'TB202507052054',2,'Ngọc Duy','ngocduy12345124@gmail.com','0358591058','Xã Tuy Phước Đông Gia Lai',1280000.00,0.00,1280000.00,'cod','pending','pending','','2025-07-05 11:11:29','2025-07-05 11:11:29'),(7,'TB202507061607',2,'Ngọc Duy','ngocduy12345124@gmail.com','0358591058','Tuy Phước Bình Định',480000.00,30000.00,510000.00,'cod','pending','shipping','','2025-07-06 06:21:28','2025-07-07 10:04:31'),(8,'TB202512260116',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',305000.00,30000.00,335000.00,'momo','pending','pending','','2025-12-26 19:11:46','2025-12-26 19:11:46'),(9,'TB202512264962',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',610000.00,0.00,610000.00,'momo','pending','pending','','2025-12-26 19:13:02','2025-12-26 19:13:02'),(10,'TB202512262628',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',330000.00,30000.00,195000.00,'momo','pending','pending','Mã giảm giá: SINHNHATSHOP (-165,000đ)','2025-12-26 19:16:47','2025-12-26 19:16:47'),(11,'TB202512267777',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',330000.00,30000.00,329500.00,'momo','pending','pending','Mã giảm giá: HELLO2025 (-30,500đ)','2025-12-26 19:30:16','2025-12-26 19:30:16'),(12,'TB202512268605',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',330000.00,30000.00,195000.00,'momo','pending','pending','Mã giảm giá: SINHNHATSHOP (-165,000đ)','2025-12-26 19:33:17','2025-12-26 19:33:17'),(13,'TB202512261198',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',330000.00,30000.00,294000.00,'momo','paid','confirmed','Mã giảm giá: TET20226 (-66,000đ)','2025-12-26 19:40:38','2025-12-26 20:20:57'),(14,'TB202512267083',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',490000.00,30000.00,275000.00,'momo','paid','confirmed','Mã giảm giá: SINHNHATSHOP (-245,000đ)','2025-12-26 20:21:50','2025-12-26 20:22:00'),(15,'TB202512288198',8,'Duy12370','ngocduy123451238@gmail.com','0358591058','Bình Định',750000.00,0.00,750000.00,'momo','paid','confirmed','','2025-12-28 00:31:46','2025-12-28 00:31:58'),(16,'TB202512285210',8,'Duy12370','ngocduy12345123@gmail.com','0358591058','Bình Định',420000.00,30000.00,450000.00,'cod','pending','pending','','2025-12-28 15:39:01','2025-12-28 15:39:01'),(17,'TB202512284777',8,'Duy12370','ngocduy12345123@gmail.com','0358591058','Bình Định',70000.00,30000.00,65000.00,'cod','pending','pending','Mã giảm giá: SINHNHATSHOP (-35,000đ)','2025-12-28 15:47:37','2025-12-28 15:47:37'),(18,'TB202512287980',8,'Duy12370','ngocduy12345123@gmail.com','0358591058','Bình Định',70000.00,30000.00,100000.00,'momo','paid','confirmed','','2025-12-28 15:48:59','2025-12-28 15:49:12'),(19,'TB202601121889',9,'Ngọc Duy','ngocduy12345129@gmail.com','0358591058','388 Huỳnh Thị Hai, Tân Chánh Hiệp, Quận 12, Hồ Chí Minh',330000.00,30000.00,195000.00,'bank_transfer','pending','pending','Thanh Toán rr nè\nMã giảm giá: SINHNHATSHOP (-165,000đ)','2026-01-12 03:09:38','2026-01-12 03:09:38'),(20,'TB202601127891',9,'Ngọc Duy','ngocduy12345129@gmail.com','0358591058','388 Huỳnh Thị Hai, Tân Chánh Hiệp, Quận 12, Hồ Chí Minh',495000.00,30000.00,277500.00,'momo','paid','confirmed','Mã giảm giá: SINHNHATSHOP (-247,500đ)','2026-01-12 03:10:58','2026-01-12 03:11:35'),(21,'TB202601140417',9,'Ngọc Duy','ngocduy12345129@gmail.com','0358591058','388 Huỳnh Thị Hai, Tân Chánh Hiệp, Quận 12, Hồ Chí Minh',250000.00,30000.00,280000.00,'momo','paid','confirmed','','2026-01-14 05:46:40','2026-01-14 05:46:58'),(22,'TB202602049675',9,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','388 Huỳnh Văn Cù, Chánh Mỹ, Thủ Dầu Một, Bình Dương',560000.00,0.00,560000.00,'momo','paid','confirmed','','2026-02-04 03:11:27','2026-02-04 03:11:41'),(23,'TB202602045235',9,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','388 Huỳnh Văn Cù, Chánh Mỹ, Thủ Dầu Một, Bình Dương',210000.00,30000.00,198000.00,'cod','pending','pending','Mã giảm giá: TET2026 (-42,000đ)','2026-02-04 03:17:12','2026-02-04 03:17:12'),(24,'TB202602040864',9,'Ngọc Duy','ngocduy1234513@gmail.com','0358591058','388, Hòa Bình, Yên Bái',165000.00,30000.00,195000.00,'cod','pending','confirmed','','2026-02-04 03:20:27','2026-02-04 06:26:40'),(25,'TB202602048185',9,'Ngọc Duy','ngocduy12345129@gmail.com','0358591058','388, Hòa Bình, Yên Bái',140000.00,30000.00,170000.00,'momo','paid','confirmed','','2026-02-04 03:22:14','2026-02-04 03:22:27'),(26,'TB202602044066',9,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','388 Huỳnh Văn Cù, Chánh Mỹ, Thủ Dầu Một, Bình Dương',280000.00,30000.00,254000.00,'momo','paid','confirmed','Mã giảm giá: TET2026 (-56,000đ)','2026-02-04 06:23:04','2026-02-04 06:23:17'),(27,'TB202602061440',9,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','388 Huỳnh Thị Hai, Tân Chánh Hiệp, Quận 12, Hồ Chí Minh',280000.00,30000.00,254000.00,'cod','pending','pending','Mã giảm giá: TET2026 (-56,000đ)','2026-02-06 17:45:29','2026-02-06 17:45:29'),(28,'TB202602064978',9,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','388 Huỳnh Thị Hai, Tân Chánh Hiệp, Quận 12, Hồ Chí Minh',280000.00,30000.00,310000.00,'momo','paid','confirmed','','2026-02-06 17:46:18','2026-02-06 17:46:33'),(29,'TB202602064946',9,'Ngọc Duy','ngocduy12345123@gmail.com','0358591058','388 Huỳnh Thị Hai, Tân Chánh Hiệp, Quận 12, Hồ Chí Minh',280000.00,30000.00,254000.00,'momo','paid','confirmed','Mã giảm giá: TET2026 (-56,000đ)','2026-02-06 17:52:09','2026-02-06 17:52:23');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `short_description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `category_id` int(11) DEFAULT NULL,
  `main_image` varchar(255) NOT NULL,
  `gallery` text DEFAULT NULL,
  `size` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `material` varchar(100) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_limited` tinyint(1) DEFAULT 0,
  `views` int(11) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `review_count` int(11) DEFAULT 0,
  `meta_title` varchar(200) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `status` enum('active','inactive','out_of_stock') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_products_category` (`category_id`),
  KEY `idx_products_featured` (`is_featured`),
  KEY `idx_products_status` (`status`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Gấu Teddy Nâu Classic','gau-teddy-nau-classic','Chú gấu Teddy nâu truyền thống với chất liệu mềm mại, an toàn cho trẻ em. Thiết kế cổ điển, đáng yêu.','Gấu Teddy nâu cổ điển, mềm mại và an toàn',140000.00,120000.00,57,1,'teddy-01.jpg',NULL,'M','Nâu','Cotton, Polyester',0.50,1,0,92,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-07-07 03:58:28'),(2,'Gấu Teddy Hồng Dễ Thương','gau-teddy-hong-de-thuong','Chú gấu màu hồng xinh xắn, perfect cho các bé gái. Chất liệu cao cấp, màu sắc tươi sáng.','Gấu Teddy màu hồng xinh xắn cho bé gái',180000.00,160000.00,43,1,'teddy-02.jpg',NULL,'M','Hồng','Plush, Cotton',0.60,1,0,32,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-12-28 00:34:11'),(3,'Gấu Panda Đen Trắng','gau-panda-den-trang','Chú gấu Panda với màu đen trắng đặc trưng, biểu cảm dễ thương và thiết kế chân thực.','Gấu Panda đen trắng với biểu cảm dễ thương',220000.00,200000.00,23,2,'panda-01.jpg',NULL,'L','Đen Trắng','Premium Plush',0.80,1,0,22,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-12-26 16:33:33'),(4,'Gấu Bắc Cực Trắng','gau-bac-cuc-trang','Chú gấu Bắc Cực màu trắng tinh khôi, lông mềm mịn như tuyết, size lớn để ôm.','Gấu Bắc Cực trắng mềm mịn như tuyết',250000.00,NULL,17,5,'polar-01.jpg',NULL,'L','Trắng','Soft Plush',1.00,0,0,21,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-12-28 00:31:46'),(5,'Gấu Koala Xám Úc','gau-koala-xam-uc','Chú gấu Koala xám từ Úc, tai to tròn đặc trưng, expression siêu cute và đáng yêu.','Gấu Koala xám với tai tròn đặc trưng',200000.00,180000.00,30,5,'koala-01.jpg',NULL,'M','Xám','Australian Plush',0.70,0,0,4,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-06-28 12:55:49'),(6,'Gấu Teddy Xanh Dương','gau-teddy-xanh-duong','Gấu Teddy màu xanh dương độc đáo, màu sắc tươi mới và nổi bật, chất liệu cao cấp.','Gấu Teddy xanh dương độc đáo và nổi bật',170000.00,NULL,39,1,'teddy-blue.jpg',NULL,'M','Xanh Dương','Premium Cotton',0.50,0,0,3,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-06-29 15:38:40'),(7,'Gấu Khổng Lồ 1m2','gau-khong-lo-1m2','Chú gấu khổng lồ cao 1m2, perfect để trang trí phòng hoặc làm quà tặng đặc biệt.','Gấu khổng lồ 1m2 - quà tặng đặc biệt',350000.00,320000.00,10,3,'giant-bear.jpg',NULL,'XL','Nâu Nhạt','Giant Plush',2.50,1,0,1,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-06-13 14:13:30'),(8,'Gấu Thỏ Hybrid','gau-tho-hybrid','Sự kết hợp độc đáo giữa gấu Teddy và thỏ, với tai dài và mũi nhỏ siêu đáng yêu.','Gấu lai thỏ với tai dài đáng yêu',190000.00,NULL,28,4,'bunny-bear.jpg',NULL,'M','Trắng Hồng','Soft Mix',0.60,0,0,3,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-06-28 11:43:52'),(9,'Gấu Unicorn Kỳ Lân','gau-unicorn-ky-lan','Gấu Unicorn với sừng kỳ lân và cánh thiên thần, màu sắc pastel cực kỳ đặc biệt.','Gấu Unicorn với sừng và cánh thiên thần',280000.00,250000.00,35,4,'unicorn-bear.jpg',NULL,'L','Pastel Rainbow','Fantasy Plush',0.90,1,1,3,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-07-04 19:11:46'),(10,'Đôi Gấu Tình Yêu','doi-gau-tinh-yeu','Cặp đôi gấu Teddy cầm tim, symbolize tình yêu và sự gắn bó, quà tặng romantic.','Cặp đôi gấu Teddy cầm tim tình yêu',320000.00,NULL,18,4,'couple-bears.jpg',NULL,'M','Đỏ Trắng','Love Edition',1.20,1,0,2,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-06-13 14:17:56'),(11,'Gấu Noel Giáng Sinh','gau-noel-giang-sinh','Chú gấu mặc trang phục Noel với mũ đỏ, perfect cho mùa Giáng Sinh ấm áp.','Gấu Noel với trang phục Giáng Sinh',240000.00,220000.00,22,4,'christmas-bear.jpg',NULL,'L','Đỏ Trắng','Christmas Special',0.80,0,1,5,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-06-25 19:16:55'),(12,'Gấu Limited Gold Edition','gau-limited-gold-edition','Phiên bản giới hạn với chất liệu đặc biệt và chi tiết mạ vàng, collector item.','Gấu phiên bản giới hạn mạ vàng',450000.00,NULL,5,4,'limited-bear.jpg',NULL,'L','Vàng Đồng','Limited Gold',1.00,1,1,4,0.00,0,NULL,NULL,'active','2025-06-07 16:50:38','2025-06-30 18:55:28'),(13,'Gấu Teddy Trắng Ngọc Trai','gau-teddy-trang-ngoc-trai','Gấu Teddy màu trắng tinh khôi như ngọc trai, lông mềm mịn cao cấp, thích hợp làm quà cưới.','Gấu Teddy trắng ngọc trai cao cấp',160000.00,140000.00,15,1,'teddy-white.jpg',NULL,'M','Trắng','Premium Cotton',0.55,0,0,52,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2026-02-06 17:52:09'),(14,'Gấu Teddy Xám Khói','gau-teddy-xam-khoi','Gấu Teddy màu xám khói sang trọng, phong cách hiện đại, phù hợp mọi không gian trang trí.','Gấu Teddy xám khói sang trọng',165000.00,NULL,21,1,'teddy-gray.jpg',NULL,'M','Xám Khói','Soft Plush',0.60,0,0,6,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2026-02-04 03:20:27'),(15,'Gấu Teddy Mini Pocket','gau-teddy-mini-pocket','Gấu Teddy size mini siêu cute, có thể bỏ túi mang theo, móc khóa đáng yêu.','Gấu Teddy mini bỏ túi siêu cute',80000.00,70000.00,88,1,'teddy-mini.jpg',NULL,'S','Nâu Nhạt','Micro Plush',0.20,1,0,6,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2026-02-04 03:17:12'),(16,'Gấu Teddy Caramel','gau-teddy-caramel','Gấu Teddy màu caramel ấm áp, chất liệu siêu mềm, biểu cảm dễ thương không thể cưỡng lại.','Gấu Teddy màu caramel ấm áp',175000.00,NULL,42,1,'teddy-caramel.jpg',NULL,'M','Caramel','Ultra Soft',0.65,0,0,3,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-04 21:07:53'),(17,'Gấu Teddy Violet Dreams','gau-teddy-violet-dreams','Gấu Teddy màu tím lavender mơ màng, lông mềm như mây, mang lại cảm giác thư giãn.','Gấu Teddy tím lavender mơ màng',185000.00,165000.00,30,1,'teddy-violet.jpg',NULL,'L','Tím Lavender','Cloud Soft',0.70,1,0,4,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-12-28 15:18:44'),(18,'Gấu Teddy Kem Vanilla','gau-teddy-kem-vanilla','Gấu Teddy màu kem vanilla ngọt ngào, thiết kế vintage classic, hoài cổ và đáng yêu.','Gấu Teddy kem vanilla vintage',155000.00,NULL,35,1,'teddy-cream.jpg',NULL,'M','Kem','Vintage Plush',0.58,0,0,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(19,'Gấu Teddy Royal Blue','gau-teddy-royal-blue','Gấu Teddy màu xanh hoàng gia sang trọng, chất liệu cao cấp, phù hợp làm quà tặng VIP.','Gấu Teddy xanh hoàng gia sang trọng',195000.00,175000.00,25,1,'teddy-royal.jpg',NULL,'L','Xanh Hoàng Gia','Royal Plush',0.75,1,0,2,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-12-26 18:39:51'),(20,'Gấu Teddy Sunshine Yellow','gau-teddy-sunshine-yellow','Gấu Teddy màu vàng sunshine tươi sáng, mang lại năng lượng tích cực và niềm vui.','Gấu Teddy vàng sunshine tươi sáng',170000.00,NULL,40,1,'teddy-yellow.jpg',NULL,'M','Vàng Sunshine','Happy Plush',0.60,0,0,4,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2026-01-14 05:55:30'),(21,'Gấu Panda Baby Cute','gau-panda-baby-cute','Gấu Panda con siêu đáng yêu, tai tròn nhỏ xinh, biểu cảm ngây thơ như em bé.','Gấu Panda baby siêu đáng yêu',190000.00,170000.00,32,2,'panda-baby.jpg',NULL,'M','Đen Trắng','Baby Soft',0.50,1,0,1,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-04 20:08:19'),(22,'Gấu Panda Giant Hug','gau-panda-giant-hug','Gấu Panda size lớn để ôm, mềm mại và ấm áp, perfect cho những cái ôm thật chặt.','Gấu Panda lớn để ôm ấm áp',280000.00,250000.00,13,2,'panda-giant.jpg',NULL,'XL','Đen Trắng','Hug Plush',1.50,1,0,6,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2026-01-14 05:46:40'),(23,'Gấu Panda Zen Master','gau-panda-zen-master','Gấu Panda thiền định, tư thế ngồi thiền, mang lại cảm giác bình yên và thư thái.','Gấu Panda thiền định bình yên',210000.00,NULL,28,2,'panda-zen.jpg',NULL,'L','Đen Trắng','Zen Plush',0.80,0,1,3,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-12-27 08:02:13'),(24,'Gấu Panda Red Heart','gau-panda-red-heart','Gấu Panda ôm trái tim đỏ, biểu tượng của tình yêu và sự quan tâm chân thành.','Gấu Panda ôm tim tình yêu',225000.00,200000.00,22,2,'panda-heart.jpg',NULL,'L','Đen Trắng Đỏ','Love Plush',0.90,1,0,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(25,'Gấu Khổng Lồ Brown Giant','gau-khong-lo-brown-giant','Gấu khổng lồ màu nâu cao 1.5m, siêu to khổng lồ, làm quà tặng wow factor tuyệt đối.','Gấu khổng lồ 1.5m wow factor',450000.00,400000.00,8,3,'giant-brown.jpg',NULL,'XXL','Nâu Đậm','Giant Soft',3.00,1,0,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(26,'Gấu Khổng Lồ White Angel','gau-khong-lo-white-angel','Gấu khổng lồ trắng như thiên thần, size 1.2m, mềm mịn như mây, quà tặng thiên thần.','Gấu khổng lồ trắng thiên thần 1.2m',380000.00,350000.00,12,3,'giant-white.jpg',NULL,'XXL','Trắng Thiên Thần','Angel Soft',2.80,1,0,1,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:57:24'),(27,'Gấu Khổng Lồ Pink Princess','gau-khong-lo-pink-princess','Gấu khổng lồ hồng công chúa, size 1.3m, dành cho những nàng công chúa nhỏ.','Gấu khổng lồ hồng công chúa 1.3m',420000.00,380000.00,10,3,'giant-pink.jpg',NULL,'XXL','Hồng Công Chúa','Princess Plush',2.90,1,0,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(28,'Gấu Khổng Lồ Golden Luxury','gau-khong-lo-golden-luxury','Gấu khổng lồ vàng ánh kim sang trọng, size 1.4m, phiên bản luxury cao cấp.','Gấu khổng lồ vàng luxury 1.4m',550000.00,500000.00,5,3,'giant-gold.jpg',NULL,'XXL','Vàng Ánh Kim','Luxury Gold',3.20,1,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(29,'Gấu Galaxy Universe','gau-galaxy-universe','Gấu Galaxy với họa tiết vũ trụ sao băng, phát sáng trong đêm, siêu độc đáo.','Gấu Galaxy phát sáng vũ trụ',320000.00,290000.00,15,4,'galaxy-bear.jpg',NULL,'L','Galaxy Multi','Glow Plush',1.00,1,1,1,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-05 00:47:38'),(30,'Gấu Rainbow Magic','gau-rainbow-magic','Gấu cầu vồng ma thuật với 7 màu sắc, mang lại may mắn và hạnh phúc.','Gấu cầu vồng ma thuật 7 màu',295000.00,265000.00,18,4,'rainbow-bear.jpg',NULL,'L','Cầu Vồng','Magic Plush',0.85,1,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(31,'Gấu Angel Wings','gau-angel-wings','Gấu thiên thần với đôi cánh trắng muốt, halo vàng, mang lại bình an và may mắn.','Gấu thiên thần cánh trắng',275000.00,NULL,20,4,'angel-bear.jpg',NULL,'L','Trắng Vàng','Angel Plush',0.90,0,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(32,'Gấu Dragon Fire','gau-dragon-fire','Gấu rồng lửa với vảy long lanh, cánh rồng mini, phong cách fantasy độc đáo.','Gấu rồng lửa fantasy độc đáo',340000.00,310000.00,12,4,'dragon-bear.jpg',NULL,'L','Đỏ Lửa','Dragon Plush',1.10,1,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(33,'Gấu Mèo Hybrid Kawaii','gau-meo-hybrid-kawaii','Sự kết hợp giữa gấu và mèo, tai nhọn cute, râu mèo, phong cách kawaii Nhật Bản.','Gấu mèo kawaii Nhật Bản',185000.00,165000.00,35,5,'cat-bear.jpg',NULL,'M','Cam Trắng','Kawaii Soft',0.60,0,0,1,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2026-01-14 06:26:20'),(34,'Gấu Chó Corgi Smile','gau-cho-corgi-smile','Gấu chó Corgi với nụ cười tươi rói, chân ngắn đáng yêu, tai cụp siêu cute.','Gấu chó Corgi nụ cười tươi',195000.00,NULL,30,5,'corgi-bear.jpg',NULL,'M','Vàng Trắng','Smile Plush',0.70,0,0,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(35,'Gấu Cáo Firefox','gau-cao-firefox','Gấu cáo lửa với đuôi dài bông xù, tai nhọn thông minh, màu cam rực rỡ.','Gấu cáo lửa đuôi xù thông minh',220000.00,200000.00,25,5,'fox-bear.jpg',NULL,'L','Cam Đỏ','Smart Plush',0.80,1,0,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(36,'Gấu Voi Elephant Wisdom','gau-voi-elephant-wisdom','Gấu voi khôn ngoan với vòi dài, tai to phập phồng, biểu tượng trí tuệ và may mắn.','Gấu voi khôn ngoan may mắn',240000.00,220000.00,20,5,'elephant-bear.jpg',NULL,'L','Xám Nhạt','Wisdom Plush',1.00,0,0,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(37,'Gấu Diamond Sparkle','gau-diamond-sparkle','Gấu kim cương lấp lánh với pha lê Swarovski, phiên bản giới hạn chỉ 50 con.','Gấu kim cương Swarovski limited',680000.00,650000.00,3,4,'diamond-bear.jpg',NULL,'L','Bạch Kim','Diamond Luxury',1.20,1,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(38,'Gấu Christmas Snow','gau-christmas-snow','Gấu Noel tuyết trắng với mũ Santa đỏ, khăn len ấm, chỉ bán mùa Giáng Sinh.','Gấu Noel tuyết trắng mùa đông',260000.00,230000.00,25,4,'snow-bear.jpg',NULL,'L','Trắng Đỏ','Winter Special',0.90,1,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(39,'Gấu Valentine Love','gau-valentine-love','Gấu Valentine ôm hoa hồng đỏ, tim đập lồng ngực, chỉ bán ngày lễ tình nhân.','Gấu Valentine hoa hồng tình yêu',299000.00,270000.00,14,4,'valentine-bear.jpg',NULL,'L','Đỏ Hồng','Love Special',0.85,1,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11'),(40,'Gấu Halloween Pumpkin','gau-halloween-pumpkin','Gấu Halloween bí ngô với mũ phù thủy, phát sáng trong đêm, phiên bản ma quái cute.','Gấu Halloween bí ngô phù thủy',310000.00,280000.00,18,4,'halloween-bear.jpg',NULL,'L','Cam Đen','Spooky Cute',0.95,1,1,0,0.00,0,NULL,NULL,'active','2025-07-01 12:10:11','2025-07-01 12:10:11');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `comment` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_reviews_product` (`product_id`),
  KEY `idx_reviews_status` (`status`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (1,1,NULL,'Test User 2025-12-27 09:26:19',5,'This is a test review!','pending','2025-12-27 08:26:19'),(2,1,NULL,'Test User 1766824011',5,'Test comment','pending','2025-12-27 08:26:51'),(3,1,NULL,'Test User 1766824050',5,'Test comment','pending','2025-12-27 08:27:30'),(4,1,NULL,'Test From Form',5,'This is a test from form','pending','2025-12-27 08:27:36'),(5,22,NULL,'Real Form Test',4,'This is the actual test','pending','2025-12-27 08:29:01'),(6,1,NULL,'Test User 1766824146',5,'Test comment','pending','2025-12-27 08:29:06'),(7,4,NULL,'Duy',5,'sản phẩm rất tốt nè','pending','2025-12-27 08:30:48'),(8,22,NULL,'Duy',5,'sản phẩm rất tốt nè','pending','2025-12-27 08:32:48'),(9,1,NULL,'Test User 1766939770',5,'Test comment','pending','2025-12-28 16:36:10'),(10,20,NULL,'Duy',5,'Sản phẩm tốt đúng size','pending','2026-01-14 05:55:28'),(11,13,NULL,'Ngọc Duy',5,'sản pẩm gấu tốt','pending','2026-02-04 03:08:41');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'site_name','Teddy Bear Paradise','Tên website','2025-06-07 16:50:38'),(2,'site_description','Cửa hàng gấu bông đáng yêu nhất Việt Nam','Mô tả website','2025-06-07 16:50:38'),(3,'contact_email','info@teddyparadise.com','Email liên hệ','2025-06-07 16:50:38'),(4,'contact_phone','0123-456-789','Số điện thoại liên hệ','2025-06-07 16:50:38'),(5,'contact_address','123 Đường Cute, Quận 1, TP.HCM','Địa chỉ liên hệ','2025-06-07 16:50:38'),(6,'shipping_fee','30000','Phí ship mặc định','2025-06-07 16:50:38'),(7,'free_shipping_min','500000','Minimum cho free ship','2025-06-07 16:50:38'),(8,'facebook_url','https://facebook.com/teddyparadise','Facebook URL','2025-06-07 16:50:38'),(9,'instagram_url','https://instagram.com/teddyparadise','Instagram URL','2025-06-07 16:50:38'),(10,'about_us','Teddy Bear Paradise - nơi mang đến những chú gấu bông đáng yêu nhất!','Giới thiệu về shop','2025-06-07 16:50:38');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `avatar` varchar(255) DEFAULT 'default-avatar.png',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active',
  `gender` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ngocduy12345123','ngocduy12345123@gmail.com','$2y$10$11ic1N8f6imE4DYZD6g1aOJn5otgjKS0R60qm4G4SY5MYHtPRpila','Ngọc Duy','0358591058',NULL,'default-avatar.png','2025-06-19 15:39:21','2025-06-19 15:39:21','active',NULL,NULL),(2,'ngocduy12345124','ngocduy12345124@gmail.com','$2y$10$riyQEr46L604xm49czEs4uw1JqWdbDry2L5NcUDKnpt0UwFOsvzJK','Ngọc Duy','0358591058',NULL,'default-avatar.png','2025-06-20 14:01:53','2025-06-20 14:01:53','active',NULL,NULL),(3,'duynn1809','duynn1809@ut.edu.vn','$2y$10$v/lQRs3sXRz24X0oggNhYufGbXV8WgfWmze6X6von6HzdlzvsjdAi','Ngọc Duy','0358591058',NULL,'default-avatar.png','2025-06-20 18:22:08','2025-06-20 18:22:08','active',NULL,NULL),(4,'ngocduy123451245','ngocduy123451245@gmail.com','$2y$10$4EMzeM2F5Vbm8mhSD1xQ3eh5HFbhqCLHeY3zMPHC1slSO4WwJf20G','Ngọc Duy2','0358591051',NULL,'default-avatar.png','2025-07-01 11:03:49','2025-07-01 11:03:49','active',NULL,NULL),(5,'ngocduy1234512','ngocduy1234512@gmail.com','$2y$10$l71LJJkTmwo9n1mYhx2vzuCwmI52hgKJRKJzbBfOtXqqLd5YT7AEm','Ngọc Duy11','0358591057',NULL,'default-avatar.png','2025-07-04 09:20:56','2025-07-04 09:20:56','active',NULL,NULL),(6,'ngocduy123451244','ngocduy123451244@gmail.com','$2y$10$P4k/8sRjeeKE4GyqdPBDDOusgMRbIO8cJfeZtzRJMQHXg2c8yFCuO','Ngọc Duy22','0358591088',NULL,'default-avatar.png','2025-07-04 20:47:16','2025-07-04 20:47:16','active',NULL,NULL),(7,'ngocduy123451246','ngocduy123451246@gmail.com','$2y$10$jqkoEraW6xjh5P5uARQUreWJydnIGvnw8kujvkhbNgEulLDTdznVi','Ngọc Duy11','0358591051',NULL,'default-avatar.png','2025-07-04 23:32:31','2025-07-04 23:32:31','active',NULL,NULL),(8,'ngocduy123451238','ngocduy123451238@gmail.com','$2y$10$fDBkR/xgUmjM29vgFY0jDexFKL28vauLINjbi2kK2fZcyXr2VS6p2','Duy12370','0358591058',NULL,'default-avatar.png','2025-12-26 18:06:11','2025-12-26 18:06:11','active',NULL,NULL),(9,'ngocduy12345129','ngocduy12345129@gmail.com','$2y$10$c2ESpA80gcBQFASMJDhJhOM0uyU2Avbug6odIFPFyMAiYyuko33xW','Ngọc Duy','0358591058',NULL,'default-avatar.png','2026-01-11 13:39:36','2026-01-11 13:39:36','active',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-16 16:56:41
